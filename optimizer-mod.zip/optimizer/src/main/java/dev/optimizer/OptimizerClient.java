package dev.optimizer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

public class OptimizerClient implements ClientModInitializer {
    private static boolean wasDown = false;

    @Override
    public void onInitializeClient() {
        VelocityModule.load();

        // Tus ile ac/kapat (sadece oyun ekranindayken)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (VelocityModule.key < 0 || client.currentScreen != null || client.player == null) {
                wasDown = false;
                return;
            }
            boolean down = GLFW.glfwGetKey(client.getWindow().getHandle(), VelocityModule.key) == GLFW.GLFW_PRESS;
            if (down && !wasDown) {
                VelocityModule.enabled = !VelocityModule.enabled;
                VelocityModule.save();
                client.player.sendMessage(Text.literal("V: " + (VelocityModule.enabled ? "on" : "off")), true);
            }
            wasDown = down;
        });

        // Sadece ".velocity" ile baslayan mesajlar sunucuya gitmez, diger her sey normal gider
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            String m = message.trim();
            String lower = m.toLowerCase(Locale.ROOT);
            if (lower.equals(".velocity")) {
                handle("help");
                return false;
            }
            if (lower.startsWith(".velocity ")) {
                handle(m.substring(".velocity ".length()).trim());
                return false;
            }
            return true;
        });
    }

    private static void say(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("[Optimizer] " + s), false);
    }

    private static void handle(String line) {
        String[] a = line.split("\\s+");
        String cmd = a[0].toLowerCase(Locale.ROOT);
        try {
            switch (cmd) {
                case "on", "ac", "aç", "open" -> { VelocityModule.enabled = true; say("V: on"); }
                case "off", "kapat", "kapa", "close" -> { VelocityModule.enabled = false; say("V: off"); }
                case "status" -> say(VelocityModule.status());
                case "bind" -> {
                    if (a.length < 2) { say("Kullanim: .velocity bind <tus>  (ornek: g, f6, rshift)"); return; }
                    int code = parseKey(a[1]);
                    if (code < 0) { say("Taninmayan tus: " + a[1]); return; }
                    VelocityModule.key = code;
                    VelocityModule.keyName = a[1].toUpperCase(Locale.ROOT);
                    say("Tus atandi: " + VelocityModule.keyName);
                }
                case "unbind" -> { VelocityModule.key = -1; VelocityModule.keyName = "yok"; say("Tus kaldirildi"); }
                case "mode" -> {
                    if (a.length < 2) { say("Kullanim: .velocity mode cancel|percent|chance"); return; }
                    VelocityModule.mode = VelocityModule.Mode.valueOf(a[1].toUpperCase(Locale.ROOT));
                    say("Mod: " + a[1].toLowerCase(Locale.ROOT));
                }
                case "h" -> { VelocityModule.horizontal = range(a, 0, 1); say("Horizontal: " + VelocityModule.horizontal); }
                case "v" -> { VelocityModule.vertical = range(a, 0, 1); say("Vertical: " + VelocityModule.vertical); }
                case "chance" -> { VelocityModule.chance = range(a, 0, 100); say("Chance: " + VelocityModule.chance + "%"); }
                case "help" -> say(".velocity ac|kapat|status|bind <tus>|unbind|mode <cancel|percent|chance>|h <0-1>|v <0-1>|chance <0-100>");
                default -> { say("Bilinmeyen komut. .velocity help yaz"); return; }
            }
            VelocityModule.save();
        } catch (Exception e) {
            say("Gecersiz deger. .velocity help yaz");
        }
    }

    private static double range(String[] a, double min, double max) {
        double v = Double.parseDouble(a[1].replace(',', '.'));
        if (v < min || v > max) throw new IllegalArgumentException();
        return v;
    }

    private static int parseKey(String raw) {
        String k = raw.toLowerCase(Locale.ROOT);
        if (k.length() == 1) {
            char c = k.charAt(0);
            if (c >= 'a' && c <= 'z') return GLFW.GLFW_KEY_A + (c - 'a');
            if (c >= '0' && c <= '9') return GLFW.GLFW_KEY_0 + (c - '0');
        }
        if (k.matches("f([1-9]|1[0-2])")) return GLFW.GLFW_KEY_F1 + Integer.parseInt(k.substring(1)) - 1;
        return switch (k) {
            case "space" -> GLFW.GLFW_KEY_SPACE;
            case "tab" -> GLFW.GLFW_KEY_TAB;
            case "lshift" -> GLFW.GLFW_KEY_LEFT_SHIFT;
            case "rshift" -> GLFW.GLFW_KEY_RIGHT_SHIFT;
            case "lctrl" -> GLFW.GLFW_KEY_LEFT_CONTROL;
            case "rctrl" -> GLFW.GLFW_KEY_RIGHT_CONTROL;
            case "lalt" -> GLFW.GLFW_KEY_LEFT_ALT;
            case "ralt" -> GLFW.GLFW_KEY_RIGHT_ALT;
            case "up" -> GLFW.GLFW_KEY_UP;
            case "down" -> GLFW.GLFW_KEY_DOWN;
            case "left" -> GLFW.GLFW_KEY_LEFT;
            case "right" -> GLFW.GLFW_KEY_RIGHT;
            case "insert" -> GLFW.GLFW_KEY_INSERT;
            case "delete" -> GLFW.GLFW_KEY_DELETE;
            case "home" -> GLFW.GLFW_KEY_HOME;
            case "end" -> GLFW.GLFW_KEY_END;
            case "pageup" -> GLFW.GLFW_KEY_PAGE_UP;
            case "pagedown" -> GLFW.GLFW_KEY_PAGE_DOWN;
            case "grave" -> GLFW.GLFW_KEY_GRAVE_ACCENT;
            default -> -1;
        };
    }
}
