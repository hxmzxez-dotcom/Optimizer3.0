package dev.optimizer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ThreadLocalRandom;

public class VelocityModule {
    public enum Mode { CANCEL, PERCENT, CHANCE }

    public static boolean enabled = true;
    public static Mode mode = Mode.CANCEL;
    public static double horizontal = 0.0; // percent modu: 0.0 - 1.0
    public static double vertical = 0.0;   // percent modu: 0.0 - 1.0
    public static double chance = 100.0;   // chance modu: knockback'in yok sayilma yuzdesi
    public static int key = -1;            // GLFW tus kodu, -1 = atanmamis
    public static String keyName = "yok";

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static class Data {
        boolean enabled = true;
        String mode = "CANCEL";
        double horizontal = 0.0;
        double vertical = 0.0;
        double chance = 100.0;
        int key = -1;
        String keyName = "yok";
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("optimizer.json");
    }

    public static void load() {
        try {
            Path p = file();
            if (!Files.exists(p)) return;
            try (Reader r = Files.newBufferedReader(p)) {
                Data d = GSON.fromJson(r, Data.class);
                if (d == null) return;
                enabled = d.enabled;
                mode = Mode.valueOf(d.mode);
                horizontal = d.horizontal;
                vertical = d.vertical;
                chance = d.chance;
                key = d.key;
                keyName = d.keyName == null ? "yok" : d.keyName;
            }
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            Data d = new Data();
            d.enabled = enabled;
            d.mode = mode.name();
            d.horizontal = horizontal;
            d.vertical = vertical;
            d.chance = chance;
            d.key = key;
            d.keyName = keyName;
            try (Writer w = Files.newBufferedWriter(file())) {
                GSON.toJson(d, w);
            }
        } catch (Exception ignored) {}
    }

    /** chance modunda bu vurus yok sayilsin mi? */
    public static boolean rollIgnore() {
        return ThreadLocalRandom.current().nextDouble() * 100.0 < chance;
    }

    public static String status() {
        return "Velocity " + (enabled ? "ON" : "OFF")
            + " | mod: " + mode.name().toLowerCase()
            + " | h: " + horizontal + " v: " + vertical
            + " | chance: " + chance + "%"
            + " | tus: " + keyName;
    }
}
